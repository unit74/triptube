package com.ssafy.triptube.trips.categories.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ssafy.triptube.trips.categories.models.Cat1Entity;

public interface Cat1Repository extends JpaRepository<Cat1Entity, String> {

}
