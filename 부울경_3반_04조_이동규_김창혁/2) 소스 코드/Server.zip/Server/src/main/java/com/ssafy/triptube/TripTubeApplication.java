package com.ssafy.triptube;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripTubeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TripTubeApplication.class, args);
	}

}
